setwd("C:\\Users\\IT24101297\\Desktop\\Lab 05")

#Exercise
#01

#i
#Binomial Distribution
#Here, Random veriable X has Binomial Distribution with n = 50 and p = 0.85 

#ii
pbinom(47,50,0.85,lower.tail = FALSE)

#02

#i
#Customer calls per hour

#ii
#Poisson Distribution
#Here, Random veriable X has Poisson Distribution with lamda = 12 

#iii
dpois(15,12)
